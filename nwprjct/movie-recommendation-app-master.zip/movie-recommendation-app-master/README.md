# Movie Recommender Android App
    made on 21/09/20 
# ingredients :-
    android studio , java and javascript
# version updates
    version 1.0 -> 21/09/20 -> created
    version 1.1 -> 23/09/20 -> toolbar added on top
    version 1.2 -> 26/09/20 -> movie search option added

